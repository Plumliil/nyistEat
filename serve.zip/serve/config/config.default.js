// // 默认配置
// module.exports={
//     dbUri:'mongodb://root:123456@124.70.8.61:27017/blogData?authSource=admin',
// }

// 默认配置
module.exports = {
    // dbUri: 'mongodb://localhost:27017/nyistEat',
    dbUri: 'mongodb://rootLi:123456@180.76.195.252:27017/NyistEat?authSource=admin',
    jwtSecret: 'd05965ae-0b9b-11ec-9a03-0242ac130003'
}